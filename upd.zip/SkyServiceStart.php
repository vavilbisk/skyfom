<?php
function startskyservice() {
    // Проверка операционной системы
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        exec('start cmd /c install_SkyService.bat');
    } else {
        echo "Эта функция поддерживается только на Windows.";
    }
}

// Вызов функции
startskyservice();
header('Location: https://skyfom.42web.io/app/dashboard.php');
exit;
?>