<?php
function openNotepad() {
    // Проверка операционной системы
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows
        exec('start cmd /c remove_SkyService.bat');
    } else {
        echo "Эта функция поддерживается только на Windows.";
    }
}

// Вызов функции
openNotepad();
header('Location: https://skyfom.42web.io/app/dashboard.php');
exit;
?>